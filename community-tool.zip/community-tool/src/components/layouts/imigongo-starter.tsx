const ImigongoStarter = ()=> {
    return(
        <img
            src="/images/imigongo.svg"
            alt="bottom footer"
            width="100%"
            height={5}
            className="w-full h-4 object-cover"
            />
    )
}

export default ImigongoStarter;