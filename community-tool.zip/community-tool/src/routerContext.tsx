export type RouterContext = {
  head: string,
  lang: string | undefined
}
